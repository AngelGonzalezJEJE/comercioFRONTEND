//import PeopleList from "./components/PeopleList";
//import GetAllWebsites  from "./components/WebsiteList";
import Login from "./components/Login";
import Register from "./components/Register";

const App = () => {
  return (
    <div>
      <h1>Sitios Web</h1>
      <Login />
      <Register />
    </div>
  );
};

export default App;
