import {useState,useEffect} from "react"

export default function PageDetails({url}) {
  const [page,setPage] =useState(null)

  useEffect(() => {
    async function fetchData() {
      if (!url) return;
      try{
        const response =  await fetch(url)
        if (!response.ok){
          throw new Error("Fetch error, Network response was not ok")
        }
        const data = await response.json()
        setPage(data)

      }catch(error){
        console.log("Error fetching data", error)
      }
    }
    fetchData()
  })
};