import {useState,useEffect} from "react"

export default function GetAllWebsites() {

  const [webSites,setWebsites] = useState([]);
  const [error,setError] = useState(null);
  const [loading,setLoading] = useState(true);
  const [url,setUrl] = useState('')

  useEffect(() => {

    const fetchData = async () =>{
      try{
        const response = await fetch("http://localhost:3000/api/paginaWeb", {
          method: "GET",
          headers: {
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3MzA4MjQ3ODUsImV4cCI6MTc2MjM2MDc4NX0.M3v6Wkar-Ogu5NX72DhUOltqNlfofkVC-xGtjA00nOo",
          },
        });
        if (!response.ok) {
          throw new Error(`http error! Status ${response.status}`)
        }
        const data = await response.json()
        setWebsites(data || [])
        setError(null)
      }catch(error){
        console.error("Error fetching data",error)
        setError(error.message)

      } finally{
        setLoading(false)
      }
      };
      fetchData();
    },[])

    if (loading) return <div>Cargando...</div>
    if (error) return <div>Error!: {error}</div>
    if (webSites.length === 0) return <div>No hay resultados...</div>

    return(
      <div>
        <h1>Resultados de busqueda</h1>
        {webSites.map((page) => (
          <div key="item._id" style={{border:"1px solid #ccc", padding:"16px", marginBottom:"16px"}}>
            <h2>{page.titulo || "Sin Titulo"}</h2>
            <p>Ciudad: {page.ciudad}</p>
            <p>Actividad: {page.actividad}</p>
          </div>
        ))}
      </div>
    )
}