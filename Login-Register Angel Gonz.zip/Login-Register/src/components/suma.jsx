import React, { useState } from 'react';


function Suma({ num1, num2 }) {
  const resultado = num1 + num2; // Calculate the sum

  const [mensaje, setsum] = useState('');

  const handleClick = () => {
    setsum(`El resultado de la suma es: ${resultado}`);
  };

  return (
    <div>
      <p>{mensaje}</p> 
      <button onClick={handleClick}>Suma</button> 
    </div>
  );
}

export default Suma;